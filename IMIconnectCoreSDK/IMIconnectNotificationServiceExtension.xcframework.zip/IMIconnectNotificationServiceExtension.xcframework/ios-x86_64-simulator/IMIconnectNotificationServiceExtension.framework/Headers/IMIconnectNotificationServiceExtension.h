//
//  IMIconnectNotificationServiceExtension.h
//  IMIconnectNotificationServiceExtension
//
//  Created by Jeremy Oddos on 20/07/2017.
//  Copyright © 2017 IMImobile. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IMIconnectNotificationServiceExtension.
FOUNDATION_EXPORT double IMIconnectNotificationServiceExtensionVersionNumber;

//! Project version string for IMIconnectNotificationServiceExtension.
FOUNDATION_EXPORT const unsigned char IMIconnectNotificationServiceExtensionVersionString[];

#import <IMIconnectNotificationServiceExtension/ICNotificationService.h>


